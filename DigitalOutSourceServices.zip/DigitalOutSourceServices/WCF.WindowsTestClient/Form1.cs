﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WCF.Proxy;
using WFC.DataContracts;

namespace WCF.WindowsTestClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            DigiSourceProxy proxy = new DigiSourceProxy();
            try
            {
                List<Player> list = proxy.GetListOfPlayer();

                dataGridView1.DataSource = list;

            }
            catch (Exception ex)
            {
             //do what u want here 
            }
            finally
            {
                DigiSourceProxy.CloseProxy(proxy);
            }
             
        }
    }
}
