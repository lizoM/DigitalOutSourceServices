﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Messaging;
using Question4.Models;

namespace Question4.Controllers
{
    public class PlayerController : Controller
    {
        //
        // GET: /Player/

        public ActionResult Index()
        {
            string path = @".\Private$\Players";
            MessageQueue messageQueue = new MessageQueue(path);
            messageQueue.Formatter = new XmlMessageFormatter(new[] { typeof(Player) });
            System.Messaging.Message[] messages = messageQueue.GetAllMessages();

            List<Player> lstPlayers = new List<Player>();

            for (int i = 0; i < messages.Length; i++)
            {
                Player player = (Player)messages[i].Body;
                lstPlayers.Add(player);
            }

            return View(lstPlayers);
        }


        //
        // GET: /Player/Create

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Save(FormCollection collection, List<Player> lstBatch)
        {

            DataLayer dataLayer = new DataLayer();
            dataLayer.SavePlayers(lstBatch);

            return RedirectToAction("Index");
        }

        //
        // POST: /Player/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                Player player = new Player()
                {
                    FirstName = collection["FirstName"],
                    LastName = collection["LastName"],
                    BirthDate = DateTime.Parse(collection["BirthDate"]),
                };


                string path = @".\Private$\Players";
                MessageQueue messageQueue = null;
                if (MessageQueue.Exists(path))
                {
                    messageQueue = new MessageQueue(path);
                    messageQueue.Label = "Updated Queue";
                }
                else
                {
                    MessageQueue.Create(path);
                    messageQueue = new MessageQueue(path);
                    messageQueue.Label = "Created Queue";
                }
                messageQueue.Send(player, "Player");


                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

    }
}
