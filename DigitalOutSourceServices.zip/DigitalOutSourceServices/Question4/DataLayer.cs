﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Question4.Models;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Question4
{
    public class DataLayer
    {
        private string connectionString;

        public DataLayer()
        {
            connectionString = ConfigurationManager.ConnectionStrings["DigitalOutSource"].ConnectionString;
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public void SavePlayers(List<Player> players)
        {
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                //using (SqlTransaction trans = con.BeginTransaction())
                //{
                    using (DbCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandText = "Player_insert";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.VarChar, 50));
                        cmd.Parameters.Add(new SqlParameter("@LastName", SqlDbType.VarChar, 50));
                        cmd.Parameters.Add(new SqlParameter("@BirthDate", SqlDbType.DateTime));

                        //this is just wrong......thats a lot db hits at once..bulk insert maybe will be better
                        for (int i = 0; i < players.Count; i++)
                        {

                            cmd.Parameters["@FirstName"].Value = players[i].FirstName;
                            cmd.Parameters["@BirthDate"].Value = players[i].BirthDate;
                            cmd.Parameters["@LastName"].Value = players[i].LastName;
                            cmd.ExecuteNonQuery();
                        }

                    }
                //    trans.Commit();
                //}
            }

        }
    }
}