﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace WCF.ServiceEngine
{
    public static class Utils
    {
        public static T GetField<T>(this IDataReader reader, string columnName)
        {
            if (string.IsNullOrEmpty(columnName) || columnName.Trim() == "")
            {
                throw new ArgumentException("No column name provided");
            }

            int index = reader.GetOrdinal(columnName);

            if (index < 0)
            {
                throw new ArgumentException(string.Format("Column '{0}' could not be found", columnName));
            }

            if (reader.IsDBNull(index))
            {
                if (!IsNullableType(typeof(T)) &&
                    typeof(T) != typeof(string) &&
                    typeof(T) != typeof(Guid))
                {
                    throw new ArgumentException(string.Format("Value in column '{0}' is null"), columnName);
                }
                else
                {
                    return default(T);
                }
            }

            object value = reader.GetValue(index);

            return GetValue<T>(value);
        }

        public static T GetValue<T>(object value)
        {
            if (value == null || DBNull.Value.Equals(value))
                return default(T);

            var t = typeof(T);
            return (T)Convert.ChangeType(value, Nullable.GetUnderlyingType(t) ?? t);
        }

        private static bool IsNullableType(Type type)
        {
            return (type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof(Nullable<>)));
        }
    }
}
