﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using WFC.DataContracts;

namespace WCF.ServiceEngine
{
    public class DataLayer
    {
        private string connectionString;

        public DataLayer()
        {
            connectionString = ConfigurationManager.ConnectionStrings["DigitalOutSource"].ConnectionString;
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public List<Player> GetAllPlayers()
        {
            List<Player> list = new List<Player>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();
                using (DbCommand cmd = new SqlCommand("GetAllPlayers_select", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (IDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Player player = new Player()
                            {
                                ID = reader.GetField<int>("ID"),
                                FirstName = reader.GetField<string>("FirstName"),
                                LastName = reader.GetField<string>("LastName"),
                                BirthDate = reader.GetField<DateTime>("BirthDate")
                            };
                            list.Add(player);
                        }
                    }
                }
            }
            return list;

        }
    }
}