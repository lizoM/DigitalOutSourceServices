﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WFC.DataContracts;
using System.ServiceModel;

namespace WCF.ServiceEngine
{
    public class DigiSourceService : IDigiSourceService
    {
        public List<Player> GetListOfPlayer()
        {
            DataLayer repo = new DataLayer();
            return repo.GetAllPlayers();
        }
    }
}
