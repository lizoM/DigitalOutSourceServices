﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WFC.DataContracts;
using System.ServiceModel;

namespace WCF.Proxy
{
    public class DigiSourceProxy: ClientBase<IDigiSourceService>, IDigiSourceService
    {      
    
        public DigiSourceProxy()
            : base()
        {
        }

        public List<Player> GetListOfPlayer()
        {
            try
            {
                return Channel.GetListOfPlayer();
            }
            catch (FaultException<ExceptionDetail> ex)
            {
                // do logging and/or throw the ex up.....solid say throw it up....
                throw new ApplicationException(ex.Message, ex);
            }
        }


        public static void CloseProxy(DigiSourceProxy proxy)
        {
            if (proxy != null && proxy.State != CommunicationState.Closed)
            {
                if (proxy.State == CommunicationState.Faulted)
                {
                    proxy.Abort();
                }
                else
                {
                    proxy.Close();
                }
            }
        }
    }
}
