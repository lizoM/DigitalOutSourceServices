﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceModelEx;

namespace WCF.ConsoleHost
{
    class Program
    {
        static void Main(string[] args)
        {

            ServiceHost<WCF.ServiceEngine.DigiSourceService> host = new ServiceHost<WCF.ServiceEngine.DigiSourceService>();
            host.Open();
            Console.WriteLine("Host is open...");
            for (int i = 0; i < host.Description.Endpoints.Count; i++)
            {
                Console.WriteLine("Hosting on " + host.Description.Endpoints[i].Address.Uri.ToString());
            }
            Console.ReadLine();
            host.Close();

        }
    }
}
