﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"../../MyNumbers.txt";
            List<int> lstOfTotals = new List<int>();
            Console.WriteLine("Find the file to read  in : {0}", filePath);
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        int total = 0;
                        string[] tokes = line.Split(',');
                        for (int i = 0; i < tokes.Length; i++)
                        {
                            int val;
                            bool isNumber = int.TryParse(tokes[i], out val);

                            if (isNumber)
                            {
                                total += val;
                            }
                        }
                        lstOfTotals.Add(total);
                    }
                }

                lstOfTotals.Sort();

                filePath = @"../../SumTotals.txt";

                using (StreamWriter writer = new StreamWriter(filePath, false))
                {
                    for (int i = 0; i < lstOfTotals.Count; i++)
                    {
                        writer.WriteLine(lstOfTotals[i].ToString());
                        Console.WriteLine(lstOfTotals[i].ToString());
                    }
                }

                Console.WriteLine("Find output file in : {0}", filePath);
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


    }
}
