﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Question2
{
    public class MathCal
    {
        public long Factorial(int n)
        {
            if (n == 0)
                return 1;
            return n * Factorial(n - 1);
        }

        public long Pascal(int x, int y)
        {
            //x=0 + 1 = 1
            //y=1 + 1=1
            //x=y=1
            if ((x + 1) == 1 || (y + 1) == 1 || x == y)
            {
                return 1;
            }
            else
            {
                /*
                 n/r=n!/(n-r)!r!
                or ((n-1)/(r-1)) + ((n-1)/r) 
                 */
                // return Factorial(x) / Factorial(x - y) * Factorial(y);......this incorrect...  
                return Pascal(x - 1, y - 1) + Pascal(x - 1, y);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MathCal cal = new MathCal();

            int rows = 6;
            for (int i = 0; i < rows; i++)
            {

               //could not figure out the spaces....without messing up

                for (int j = 0; j <= i; j++)
                {
                    Console.Write(cal.Pascal(i, j));
                }Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
