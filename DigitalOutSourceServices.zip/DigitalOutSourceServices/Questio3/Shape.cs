﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Question3
{
   public abstract class Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }
        public double Radius { get; set; }
    }
}
