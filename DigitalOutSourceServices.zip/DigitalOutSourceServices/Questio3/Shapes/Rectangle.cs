﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Question3
{
    public class Rectangle : Shape, IShape
    {
        public double CalculateArea()
        {
            return Width * Height;
        }
    }
}
