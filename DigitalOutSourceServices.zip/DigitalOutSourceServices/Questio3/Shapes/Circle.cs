﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Question3
{
    public class Circle : Shape, IShape
    {
        public double CalculateArea()
        {
            return Radius * Math.PI;
        }
    }
}
