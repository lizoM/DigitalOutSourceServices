﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            //logic

            DataAccessLayer dataLayer = new DataAccessLayer();

            dataLayer.Add(new Circle() { Radius = 4 });
            dataLayer.Add(new Rectangle() { Height = 4, Width = 8 });
            dataLayer.Add(new Square() { Height = 4, Width = 4 });

        }
    }
}
