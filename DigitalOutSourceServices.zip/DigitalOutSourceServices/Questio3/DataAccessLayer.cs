﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


namespace Question3
{
   public class DataAccessLayer
    {

       public void Add(Circle circle)
       {
           using (var con = new SqlConnection())
           {
               using (SqlCommand cmd = new SqlCommand("insert into [Table] values(@ShapeType, @Radius)"))
               {
                   cmd.Connection = con;
                   cmd.Parameters.Add("@ShapeType", circle.GetType());
                   cmd.Parameters.Add("@Radius", circle.Radius);
                   cmd.ExecuteNonQuery();
               }
           }

       }

       public void Add(Square square)
       {
           AddShape(square);
       }

       public void Add(Rectangle rectangle)
       {
           AddShape(rectangle);
       }

       private static void AddShape(Shape shape)
       {
           using (var con = new SqlConnection())
           {
               using (SqlCommand cmd = new SqlCommand("insert into [Table] values({0}, {1},{2})"))
               {
                   cmd.Connection = con;
                   cmd.Parameters.Add("@ShapeType", shape.GetType());
                   cmd.Parameters.Add("@Height", shape.Height);
                   cmd.Parameters.Add("@Width", shape.Width);
                   cmd.ExecuteNonQuery();
               }
           }
       }
    }
}
