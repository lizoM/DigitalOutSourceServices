﻿using Question2;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Question2UnitTests
{


    /// <summary>
    ///This is a test class for MathCalTest and is intended
    ///to contain all MathCalTest Unit Tests
    ///</summary>
    [TestClass()]
    public class Pascal
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


      
        [TestMethod()]
        public void ZeroAndOne()
        {
            MathCal target = new MathCal();
            int x = 0; 
            int y = 1; 
            long expected = 1;
            long actual;
            actual = target.Pascal(x, y);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void OneAndOne()
        {
            MathCal target = new MathCal();
            int x = 1;
            int y = 1;
            long expected = 1;
            long actual;
            actual = target.Pascal(x, y);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void EvenNumbers()
        {
            MathCal target = new MathCal();
            int x = 2;
            int y = 2;
            long expected = 4;
            long actual;
            actual = target.Pascal(x, y);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void OddNumbers()
        {
            MathCal target = new MathCal();
            int x = 3;
            int y = 3;
            long expected = 6;
            long actual;
            actual = target.Pascal(x, y);
            Assert.AreEqual(expected, actual);
        }
    }
}
